/* ============================================
   HOLOGRAPHY EDUCATIONAL WEBSITE — JAVASCRIPT
   Simulations: Canvas 2D + Three.js 3D viewer
   ============================================ */

"use strict";

// ─── Utility helpers ───────────────────────
const $ = id => document.getElementById(id);
const lerp = (a, b, t) => a + (b - a) * t;
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

// Convert wavelength (nm) to approximate RGB
function wavelengthToRGB(wl) {
  let r, g, b;
  if (wl >= 380 && wl < 440) { r = -(wl - 440) / 60; g = 0; b = 1; }
  else if (wl < 490)         { r = 0; g = (wl - 440) / 50; b = 1; }
  else if (wl < 510)         { r = 0; g = 1; b = -(wl - 510) / 20; }
  else if (wl < 580)         { r = (wl - 510) / 70; g = 1; b = 0; }
  else if (wl < 645)         { r = 1; g = -(wl - 645) / 65; b = 0; }
  else if (wl <= 780)        { r = 1; g = 0; b = 0; }
  else                       { r = 0; g = 0; b = 0; }
  const gamma = 0.8;
  const factor = wl < 420 ? 0.3 + 0.7*(wl-380)/40 : wl > 700 ? 0.3 + 0.7*(780-wl)/80 : 1;
  return [
    Math.round(255 * Math.pow(r * factor, gamma)),
    Math.round(255 * Math.pow(g * factor, gamma)),
    Math.round(255 * Math.pow(b * factor, gamma))
  ];
}
function wlCSS(wl) {
  const [r,g,b] = wavelengthToRGB(wl);
  return `rgb(${r},${g},${b})`;
}

// ─── NAV TOGGLE ────────────────────────────
$('navToggle').addEventListener('click', () => {
  document.querySelector('.nav-links').classList.toggle('open');
});

// ─── HERO CANVAS — animated wave field ─────
(function heroWaves() {
  const canvas = $('heroCanvas');
  const ctx = canvas.getContext('2d');
  let W, H, t = 0;
  const sources = [];

  function resize() {
    W = canvas.width  = canvas.offsetWidth;
    H = canvas.height = canvas.offsetHeight;
  }
  window.addEventListener('resize', resize);
  resize();

  // Create interference sources
  for (let i = 0; i < 4; i++) {
    sources.push({
      x: Math.random(),
      y: Math.random(),
      k: 0.012 + Math.random() * 0.008,
      phase: Math.random() * Math.PI * 2
    });
  }

  function draw() {
    ctx.clearRect(0, 0, W, H);
    const imageData = ctx.createImageData(W, H);
    const d = imageData.data;
    const step = 3; // sample every N pixels for speed
    for (let py = 0; py < H; py += step) {
      for (let px = 0; px < W; px += step) {
        let amp = 0;
        for (const s of sources) {
          const sx = s.x * W, sy = s.y * H;
          const dist = Math.sqrt((px-sx)**2 + (py-sy)**2);
          amp += Math.sin(dist * s.k - t + s.phase);
        }
        amp = (amp / sources.length + 1) / 2; // 0..1
        // colour: dark teal / indigo
        const brightness = amp * amp;
        const r = Math.round(brightness * 40  + 20 * amp);
        const g = Math.round(brightness * 160 + 20 * amp);
        const b = Math.round(brightness * 200 + 40);
        for (let dy = 0; dy < step; dy++) {
          for (let dx = 0; dx < step; dx++) {
            const i = ((py+dy)*W + (px+dx)) * 4;
            d[i]   = r; d[i+1] = g; d[i+2] = b; d[i+3] = 200;
          }
        }
      }
    }
    ctx.putImageData(imageData, 0, 0);
    // dark overlay for readability
    ctx.fillStyle = 'rgba(7,8,15,0.55)';
    ctx.fillRect(0, 0, W, H);
    t += 0.025;
    requestAnimationFrame(draw);
  }
  draw();
})();

// ─── PHYSICS CANVAS 1 — Interference ───────
(function interferenceAnim() {
  const canvas = $('interferenceCanvas');
  const ctx = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;
  let t = 0;

  function draw() {
    ctx.fillStyle = '#060710'; ctx.fillRect(0, 0, W, H);
    const midY = H / 2;
    const amp = 35, freq = 0.05, speed = 0.04;

    // Wave 1 (red)
    ctx.beginPath(); ctx.strokeStyle = '#ff4466'; ctx.lineWidth = 1.8;
    for (let x = 0; x < W; x++) {
      const y = midY - H*0.22 + amp * Math.sin(freq * x - t);
      x === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    }
    ctx.stroke();

    // Wave 2 (blue)
    ctx.beginPath(); ctx.strokeStyle = '#4488ff'; ctx.lineWidth = 1.8;
    for (let x = 0; x < W; x++) {
      const y = midY + H*0.22 + amp * Math.sin(freq * x - t + 0.8);
      x === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    }
    ctx.stroke();

    // Interference result (white)
    ctx.beginPath(); ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = 2;
    for (let x = 0; x < W; x++) {
      const y1 = amp * Math.sin(freq * x - t);
      const y2 = amp * Math.sin(freq * x - t + 0.8);
      const y = midY + (y1 + y2) * 0.6;
      x === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    }
    ctx.stroke();

    // Labels
    ctx.font = '10px Space Mono, monospace';
    ctx.fillStyle = '#ff4466'; ctx.fillText('Wave 1', 6, 18);
    ctx.fillStyle = '#4488ff'; ctx.fillText('Wave 2', 6, 32);
    ctx.fillStyle = 'rgba(255,255,255,0.7)'; ctx.fillText('Result', 6, 46);

    t += speed;
    requestAnimationFrame(draw);
  }
  draw();
})();

// ─── PHYSICS CANVAS 2 — Diffraction ────────
(function diffractionAnim() {
  const canvas = $('diffractionCanvas');
  const ctx = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;
  let t = 0;
  const slitX = W * 0.35;

  function draw() {
    ctx.fillStyle = '#060710'; ctx.fillRect(0, 0, W, H);

    // Incoming beam
    ctx.strokeStyle = '#5ef0c8'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(0, H/2); ctx.lineTo(slitX, H/2); ctx.stroke();
    // Arrow
    ctx.fillStyle = '#5ef0c8';
    ctx.beginPath();
    ctx.moveTo(slitX-18, H/2-5); ctx.lineTo(slitX-4, H/2); ctx.lineTo(slitX-18, H/2+5);
    ctx.fill();

    // Slit (grating)
    ctx.strokeStyle = '#7b6fff'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(slitX, 0); ctx.lineTo(slitX, H/2 - 14); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(slitX, H/2+14); ctx.lineTo(slitX, H); ctx.stroke();

    // Diffracted orders
    const orders = [
      { angle: 0,    color: '#5ef0c8', label: 'm=0' },
      { angle:  22,  color: '#ff6b9d', label: 'm=+1' },
      { angle: -22,  color: '#ff6b9d', label: 'm=−1' },
      { angle:  45,  color: '#ffaa00', label: 'm=+2' },
      { angle: -45,  color: '#ffaa00', label: 'm=−2' },
    ];
    for (const o of orders) {
      const rad = o.angle * Math.PI / 180;
      const ex = slitX + (W - slitX) * 0.92;
      const ey = H/2 + (W - slitX) * 0.92 * Math.tan(rad);
      if (ey < 0 || ey > H) continue;

      // Animated dashed ray
      ctx.setLineDash([6, 6]);
      ctx.lineDashOffset = -t * 4;
      ctx.strokeStyle = o.color; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(slitX, H/2); ctx.lineTo(ex, ey); ctx.stroke();
      ctx.setLineDash([]);

      // Label
      ctx.fillStyle = o.color; ctx.font = '10px Space Mono, monospace';
      ctx.fillText(o.label, Math.min(ex+4, W-36), clamp(ey+4, 10, H-4));
    }

    ctx.fillStyle = '#7b6fff'; ctx.font = '10px Space Mono, monospace';
    ctx.fillText('grating', slitX+3, 12);

    t += 0.05;
    requestAnimationFrame(draw);
  }
  draw();
})();

// ─── PHYSICS CANVAS 3 — Coherence toggle ───
let coherentMode = true;
$('coherenceToggle').addEventListener('click', () => {
  coherentMode = !coherentMode;
  $('coherenceToggle').textContent = coherentMode
    ? 'Toggle: Coherent ↔ Incoherent'
    : 'Toggle: Coherent ↔ Incoherent';
});
(function coherenceAnim() {
  const canvas = $('coherenceCanvas');
  const ctx = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;
  let t = 0;
  const NUM = 6;
  const phases = Array.from({length: NUM}, (_, i) => i * Math.PI * 2 / NUM);
  const randPhases = Array.from({length: NUM}, () => Math.random() * Math.PI * 2);

  function draw() {
    ctx.fillStyle = '#060710'; ctx.fillRect(0, 0, W, H);
    const midY = H / 2;

    if (coherentMode) {
      // All in phase — single clear wave
      ctx.beginPath(); ctx.strokeStyle = '#5ef0c8'; ctx.lineWidth = 2.5;
      for (let x = 0; x < W; x++) {
        const y = midY + 40 * Math.sin(0.07 * x - t);
        x === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
      }
      ctx.stroke();
      ctx.fillStyle = '#5ef0c8'; ctx.font = '11px Space Mono, monospace';
      ctx.fillText('Coherent — stable fringes', 10, H - 12);

      // Show multiple superimposed waves (same phase)
      for (let i = 0; i < NUM; i++) {
        ctx.beginPath(); ctx.strokeStyle = 'rgba(94,240,200,0.15)'; ctx.lineWidth = 1;
        for (let x = 0; x < W; x++) {
          const y = midY + 38 * Math.sin(0.07 * x - t);
          x === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
        }
        ctx.stroke();
      }
    } else {
      // Random phases — washed out
      // Update random phases slightly
      for (let i = 0; i < NUM; i++) {
        randPhases[i] += (Math.random() - 0.5) * 0.15;
      }
      // Draw individual incoherent waves
      for (let i = 0; i < NUM; i++) {
        ctx.beginPath();
        const hue = (i * 60) % 360;
        ctx.strokeStyle = `hsla(${hue},80%,60%,0.3)`; ctx.lineWidth = 1;
        for (let x = 0; x < W; x++) {
          const y = midY + 30 * Math.sin(0.07 * x - t + randPhases[i]);
          x === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
        }
        ctx.stroke();
      }
      // Sum = noise
      ctx.beginPath(); ctx.strokeStyle = 'rgba(200,180,255,0.5)'; ctx.lineWidth = 2;
      for (let x = 0; x < W; x++) {
        let sum = 0;
        for (let i = 0; i < NUM; i++) sum += 30 * Math.sin(0.07 * x - t + randPhases[i]);
        const y = midY + sum / NUM;
        x === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
      }
      ctx.stroke();
      ctx.fillStyle = '#ff6b9d'; ctx.font = '11px Space Mono, monospace';
      ctx.fillText('Incoherent — fringes wash out', 10, H - 12);
    }

    t += 0.04;
    requestAnimationFrame(draw);
  }
  draw();
})();

// ─── PHYSICS CANVAS 4 — Laser cavity ───────
(function laserAnim() {
  const canvas = $('laserCanvas');
  const ctx = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;
  let t = 0;
  const midY = H / 2;
  const m1x = 20, m2x = W - 20;
  const gainW = 120, gainH = 30;
  const gainX = W/2 - gainW/2, gainY = midY - gainH/2;

  function draw() {
    ctx.fillStyle = '#060710'; ctx.fillRect(0, 0, W, H);

    // Mirrors
    const grad1 = ctx.createLinearGradient(m1x-6,0,m1x+6,0);
    grad1.addColorStop(0,'#7b6fff'); grad1.addColorStop(1,'rgba(123,111,255,0)');
    ctx.fillStyle = grad1; ctx.fillRect(m1x-6, midY-50, 12, 100);

    const grad2 = ctx.createLinearGradient(m2x-6,0,m2x+6,0);
    grad2.addColorStop(0,'rgba(123,111,255,0)'); grad2.addColorStop(1,'#7b6fff');
    ctx.fillStyle = grad2; ctx.fillRect(m2x-6, midY-50, 12, 100);

    // Gain medium
    ctx.fillStyle = 'rgba(94,240,200,0.08)';
    ctx.strokeStyle = 'rgba(94,240,200,0.4)'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.roundRect(gainX, gainY, gainW, gainH, 4);
    ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#5ef0c8'; ctx.font = '10px Space Mono, monospace';
    ctx.textAlign = 'center'; ctx.fillText('GAIN MEDIUM', W/2, gainY - 6);
    ctx.textAlign = 'left';

    // Bouncing photon beams
    const numRays = 5;
    ctx.save();
    ctx.globalAlpha = 0.7;
    for (let i = 0; i < numRays; i++) {
      const phase = (t + i * (1/numRays)) % 1;
      const x = m1x + (m2x - m1x) * (phase < 0.5 ? phase*2 : 2 - phase*2);
      const going = phase < 0.5;
      const brightness = 0.4 + 0.6 * Math.sin(t * 8 + i * 1.5);
      ctx.beginPath();
      ctx.strokeStyle = `rgba(255,220,80,${brightness})`;
      ctx.lineWidth = 1.5;
      ctx.setLineDash([4, 6]);
      ctx.lineDashOffset = -t * 40;
      if (going) { ctx.moveTo(m1x+6, midY); ctx.lineTo(x, midY); }
      else        { ctx.moveTo(m2x-6, midY); ctx.lineTo(x, midY); }
      ctx.stroke();
      ctx.setLineDash([]);

      // Photon dot
      ctx.beginPath();
      ctx.arc(x, midY, 3, 0, Math.PI*2);
      ctx.fillStyle = `rgba(255,220,80,${brightness})`;
      ctx.fill();
    }
    ctx.restore();

    // Output beam escaping right mirror
    ctx.save();
    ctx.setLineDash([5, 4]);
    ctx.lineDashOffset = -t * 50;
    ctx.strokeStyle = '#5ef0c8'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(m2x+6, midY); ctx.lineTo(W, midY); ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = '#5ef0c8'; ctx.font = '10px Space Mono, monospace';
    ctx.fillText('laser output →', m2x+10, midY - 8);
    ctx.restore();

    // Labels
    ctx.font = '9px Space Mono, monospace';
    ctx.fillStyle = '#7b6fff'; ctx.fillText('M1 (100%)', m1x-14, midY + 65);
    ctx.fillStyle = '#7b6fff'; ctx.fillText('M2 (partial)', m2x-40, midY + 65);

    t += 0.005;
    requestAnimationFrame(draw);
  }
  draw();
})();

// ─── MAIN SIMULATION ───────────────────────
const simState = {
  wl: 532,
  angle: 30,
  dist: 150,
  platePct: 50,
  mode: 'record',
};

// Bind controls
function bindSlider(id, key, displayId, suffix='') {
  const el = $(id), disp = $(displayId);
  el.addEventListener('input', () => {
    simState[key] = +el.value;
    if (disp) disp.textContent = el.value;
    updateFringe();
  });
  if (disp) disp.textContent = el.value;
}
bindSlider('wavelength',  'wl',       'wlVal',    ' nm');
bindSlider('refAngle',    'angle',    'angleVal', '°');
bindSlider('objDist',     'dist',     'distVal',  ' mm');
bindSlider('platePct',    'platePct', 'plateVal', '%');

// Wavelength colour bar indicator
function updateWlBar() {
  const pct = (simState.wl - 380) / (780 - 380) * 100;
  const bar = $('wlBar');
  bar.style.background = `linear-gradient(to right,
    #7b00ff 0%, #0000ff 15%, #00ffff 30%, #00ff00 45%,
    #ffff00 60%, #ff8000 75%, #ff0000 100%)`;
}
$('wavelength').addEventListener('input', updateWlBar);
updateWlBar();

// Mode buttons
document.querySelectorAll('.mode-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    simState.mode = btn.dataset.mode;
    $('simInfo').innerHTML = simState.mode === 'record'
      ? '<strong>Recording Mode</strong><br/>The laser splits into a reference beam (mirror) and object beam (reflecting off the subject). Both meet at the plate and create microscopic interference fringes.'
      : '<strong>Reconstruction Mode</strong><br/>The developed plate is illuminated by the reference beam alone. The fringes diffract the light, recreating the original object beam — you see a 3D virtual image floating in space.';
  });
});

// ── Main sim canvas draw ──
const simCanvas = $('simCanvas');
const simCtx = simCanvas.getContext('2d');
let simT = 0;

function resizeSimCanvas() {
  const wrap = simCanvas.parentElement;
  simCanvas.width  = wrap.clientWidth;
  simCanvas.height = Math.round(wrap.clientWidth * 0.55);
}
window.addEventListener('resize', resizeSimCanvas);
resizeSimCanvas();

function drawSimulation() {
  const W = simCanvas.width, H = simCanvas.height;
  const ctx = simCtx;
  ctx.fillStyle = '#040509'; ctx.fillRect(0, 0, W, H);

  const wl = simState.wl;
  const angle = simState.angle;
  const dist = simState.dist;
  const platePct = simState.platePct / 100;
  const mode = simState.mode;
  const lc = wlCSS(wl);

  if (mode === 'record') {
    drawRecord(ctx, W, H, wl, angle, dist, platePct, lc);
  } else {
    drawReconstruct(ctx, W, H, wl, angle, dist, platePct, lc);
  }
  simT += 0.03;
  requestAnimationFrame(drawSimulation);
}

function drawRecord(ctx, W, H, wl, angle, dist, platePct, lc) {
  const midY = H / 2;
  // Layout positions
  const laserX = W * 0.04;
  const splitterX = W * 0.22;
  const mirrorX = W * 0.22;
  const mirrorY = H * 0.12;
  const plateX = W * (0.42 + platePct * 0.35);
  const objectX = plateX - dist / 4;
  const objectY = midY;

  // ── Laser source ──
  drawLaser(ctx, laserX, midY, 40, 20, lc, '← LASER');

  // Beam from laser to splitter (animated dashes)
  animBeam(ctx, laserX + 40, midY, splitterX, midY, lc, simT);

  // ── Beam splitter ──
  ctx.save();
  ctx.translate(splitterX, midY);
  ctx.rotate(Math.PI / 4);
  ctx.fillStyle = 'rgba(123,111,255,0.3)';
  ctx.strokeStyle = '#7b6fff'; ctx.lineWidth = 2;
  ctx.fillRect(-4, -24, 8, 48);
  ctx.strokeRect(-4, -24, 8, 48);
  ctx.restore();
  ctx.fillStyle = '#7b6fff'; ctx.font = '9px Space Mono, monospace';
  ctx.fillText('BS', splitterX + 6, midY - 18);

  // Reference beam: goes up to mirror then to plate
  animBeam(ctx, splitterX, midY, mirrorX, mirrorY, lc, simT, angle);
  // Mirror at top
  ctx.fillStyle = 'rgba(94,240,200,0.3)';
  ctx.strokeStyle = '#5ef0c8'; ctx.lineWidth = 2;
  ctx.fillRect(mirrorX - 20, mirrorY - 4, 40, 8);
  ctx.strokeRect(mirrorX - 20, mirrorY - 4, 40, 8);
  ctx.fillStyle = '#5ef0c8'; ctx.font = '9px Space Mono, monospace';
  ctx.fillText('MIRROR', mirrorX - 18, mirrorY - 8);

  // Mirror to plate (reference beam, angled)
  const refAngleRad = (angle - 15) * Math.PI / 180;
  const plateMidY = midY;
  animBeam(ctx, mirrorX, mirrorY, plateX, plateMidY - 20, lc, simT);

  // Object beam: splitter → object → plate
  animBeam(ctx, splitterX, midY, objectX - 20, midY, '#ff6b9d', simT);
  // Object
  drawObject(ctx, objectX - 20, midY, simT);
  // Scattered light from object to plate
  ctx.save();
  for (let i = -3; i <= 3; i++) {
    const targetY = plateMidY + i * (H * 0.08);
    ctx.globalAlpha = 0.35;
    animBeam(ctx, objectX, midY, plateX, targetY, '#ff6b9d', simT + i * 0.3);
  }
  ctx.restore();

  // ── Plate ──
  drawPlate(ctx, plateX, H, midY, true);

  // Interference fringes on plate
  drawPlateFringes(ctx, plateX, H, midY, wl, angle, simT);

  // Labels
  ctx.font = '10px Space Mono, monospace';
  ctx.fillStyle = '#ff6b9d'; ctx.fillText('OBJECT BEAM', splitterX + 10, midY + 14);
  ctx.fillStyle = lc; ctx.fillText('REF BEAM', mirrorX - 46, (midY + mirrorY)/2 - 8);
}

function drawReconstruct(ctx, W, H, wl, angle, dist, platePct, lc) {
  const midY = H / 2;
  const plateX = W * (0.42 + platePct * 0.35);
  const refSourceX = W * 0.06;
  const imageX = plateX - dist / 4;

  // Reference beam illuminating plate
  animBeam(ctx, refSourceX, midY * 0.6, plateX, midY - 20, lc, simT);
  // Source label
  drawLaser(ctx, refSourceX - 40, midY * 0.6 - 10, 40, 18, lc, 'REPLAY');

  // ── Plate ──
  drawPlate(ctx, plateX, H, midY, false);
  drawPlateFringes(ctx, plateX, H, midY, wl, angle, simT * 0);

  // Diffracted wavefronts reconstructing image
  ctx.save();
  for (let i = -4; i <= 4; i++) {
    ctx.globalAlpha = 0.22 + 0.06 * Math.abs(i);
    const sy = midY - 20 + i * H * 0.06;
    const ey = midY + i * H * 0.09;
    animBeam(ctx, plateX, sy, imageX, ey, lc, simT + i * 0.2);
  }
  ctx.restore();

  // Virtual image (ghost)
  ctx.save();
  ctx.globalAlpha = 0.4 + 0.25 * Math.sin(simT * 0.5);
  drawObject(ctx, imageX, midY, 0, true);
  ctx.restore();

  // Viewer eye
  const eyeX = W * 0.88, eyeY = midY;
  drawEye(ctx, eyeX, eyeY);

  // Eye trace lines to virtual image
  ctx.save();
  ctx.globalAlpha = 0.2;
  ctx.setLineDash([4,6]);
  ctx.strokeStyle = lc; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(eyeX, eyeY - 10); ctx.lineTo(imageX, midY - 30); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(eyeX, eyeY + 10); ctx.lineTo(imageX, midY + 30); ctx.stroke();
  ctx.setLineDash([]);
  ctx.restore();

  // Labels
  ctx.font = '10px Space Mono, monospace';
  ctx.fillStyle = lc; ctx.fillText('DIFFRACTED\nWAVES', plateX + 4, midY - 60);
  ctx.fillStyle = 'rgba(255,107,157,0.8)'; ctx.fillText('VIRTUAL\nIMAGE', imageX - 42, midY - 55);
}

function animBeam(ctx, x1, y1, x2, y2, color, t, angle=0) {
  ctx.save();
  ctx.strokeStyle = color; ctx.lineWidth = 2;
  ctx.shadowBlur = 6; ctx.shadowColor = color;
  ctx.setLineDash([8, 6]);
  ctx.lineDashOffset = -t * 30;
  ctx.globalAlpha = 0.85;
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
  ctx.setLineDash([]);
  ctx.restore();
}

function drawLaser(ctx, x, y, w, h, color, label) {
  const grad = ctx.createLinearGradient(x, y, x+w, y);
  grad.addColorStop(0, color); grad.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = 'rgba(0,0,0,0.7)'; ctx.strokeStyle = color; ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.roundRect(x, y - h/2, w, h, 4); ctx.fill(); ctx.stroke();
  ctx.fillStyle = color; ctx.font = '8px Space Mono, monospace';
  ctx.fillText(label || 'LASER', x + 3, y + 3);
}

function drawObject(ctx, x, y, t, ghost=false) {
  ctx.save();
  if (ghost) {
    ctx.strokeStyle = '#ff6b9d'; ctx.lineWidth = 1.5;
    ctx.shadowBlur = 12; ctx.shadowColor = '#ff6b9d';
  } else {
    ctx.strokeStyle = '#ff6b9d'; ctx.lineWidth = 2;
    ctx.fillStyle = 'rgba(255,107,157,0.1)';
  }
  // Simple tetrahedron-like shape
  ctx.beginPath();
  ctx.moveTo(x, y - 20);
  ctx.lineTo(x + 15, y + 15);
  ctx.lineTo(x - 15, y + 15);
  ctx.closePath();
  if (!ghost) ctx.fill();
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(x, y - 8, 4, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();
}

function drawEye(ctx, x, y) {
  ctx.save();
  ctx.strokeStyle = '#ffd700'; ctx.lineWidth = 2;
  ctx.fillStyle = 'rgba(255,215,0,0.1)';
  ctx.beginPath();
  ctx.ellipse(x, y, 16, 10, 0, 0, Math.PI*2); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#ffd700';
  ctx.beginPath(); ctx.arc(x, y, 5, 0, Math.PI*2); ctx.fill();
  ctx.restore();
  ctx.fillStyle = '#ffd700'; ctx.font = '9px Space Mono, monospace';
  ctx.fillText('EYE', x + 18, y + 4);
}

function drawPlate(ctx, x, H, midY, recording) {
  const color = recording ? '#7b6fff' : '#5ef0c8';
  const grad = ctx.createLinearGradient(x-4, 0, x+4, 0);
  grad.addColorStop(0, `rgba(${recording?'123,111,255':'94,240,200'},0.6)`);
  grad.addColorStop(0.5, `rgba(${recording?'123,111,255':'94,240,200'},0.1)`);
  grad.addColorStop(1, `rgba(${recording?'123,111,255':'94,240,200'},0.6)`);
  ctx.fillStyle = grad;
  ctx.fillRect(x - 4, midY - H*0.35, 8, H * 0.7);
  ctx.strokeStyle = color; ctx.lineWidth = 1.5;
  ctx.strokeRect(x - 4, midY - H*0.35, 8, H * 0.7);
  ctx.fillStyle = color; ctx.font = '8px Space Mono, monospace';
  ctx.fillText('PLATE', x - 14, midY + H * 0.37);
}

function drawPlateFringes(ctx, plateX, H, midY, wl, angle, t) {
  const fringeSpacing = calcFringeSpacing(wl, angle);
  const pixelsPerMicron = 0.12;
  const fringePixels = fringeSpacing * pixelsPerMicron;
  const plateH = H * 0.7;
  const startY = midY - H * 0.35;
  ctx.save();
  ctx.globalAlpha = 0.7;
  for (let y = startY; y < startY + plateH; y += fringePixels) {
    const brightness = 0.5 + 0.5 * Math.sin((y - startY) / fringePixels * Math.PI);
    ctx.fillStyle = `rgba(255,255,200,${brightness * 0.5})`;
    ctx.fillRect(plateX - 3, y, 6, fringePixels * 0.5);
  }
  ctx.restore();
}

function calcFringeSpacing(wl, angle) {
  // d = λ / (2 sin(θ/2)) — simplified transmission hologram formula
  const sinHalf = Math.sin((angle / 2) * Math.PI / 180);
  const d = (wl * 1e-9) / (2 * sinHalf) * 1e6; // µm
  return Math.max(0.1, d);
}

// ── Fringe pattern display ──
function updateFringe() {
  const canvas = $('fringeCanvas');
  const ctx = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;
  const { wl, angle } = simState;
  const spacing = calcFringeSpacing(wl, angle);
  const fringesPerMm = 1000 / spacing;
  const pixelsPerFringe = Math.max(1, W / (fringesPerMm * 0.6));

  ctx.fillStyle = '#04060f'; ctx.fillRect(0, 0, W, H);
  // Draw alternating bright/dark fringes
  let x = 0;
  while (x < W) {
    const brightness = 0.3 + 0.7;
    const [r,g,b] = wavelengthToRGB(wl);
    ctx.fillStyle = `rgb(${r},${g},${b})`;
    ctx.fillRect(x, 0, pixelsPerFringe * 0.5, H);
    x += pixelsPerFringe;
  }

  $('fringeSpacing').textContent = spacing.toFixed(1);
  $('fringesPerMm').textContent = fringesPerMm.toFixed(0);
}
updateFringe();
['wavelength','refAngle','objDist','platePct'].forEach(id => {
  $(id).addEventListener('input', updateFringe);
});

drawSimulation();

// ─── STAGE DIAGRAMS ─────────────────────────
(function recordDiagram() {
  const canvas = $('recordDiagram');
  const ctx = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;

  ctx.fillStyle = '#040509'; ctx.fillRect(0, 0, W, H);

  // ── Elements ──
  const lx = 30, ly = H/2;
  const bsx = 150, bsy = H/2;
  const mx = 150, my = 55;
  const ox = 310, oy = H/2;
  const px = 390, py = H/2;

  function arrow(x1,y1,x2,y2,col,label,lx2,ly2) {
    ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = 1.8;
    ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(x2,y2); ctx.stroke();
    // Arrowhead
    const ang = Math.atan2(y2-y1,x2-x1);
    ctx.beginPath();
    ctx.moveTo(x2,y2);
    ctx.lineTo(x2-10*Math.cos(ang-0.4), y2-10*Math.sin(ang-0.4));
    ctx.lineTo(x2-10*Math.cos(ang+0.4), y2-10*Math.sin(ang+0.4));
    ctx.closePath(); ctx.fill();
    if (label) {
      ctx.font = '9px Space Mono, monospace';
      ctx.fillStyle = col;
      ctx.fillText(label, lx2 ?? (x1+x2)/2-20, ly2 ?? (y1+y2)/2-6);
    }
  }

  function box(x,y,w,h,col,label) {
    ctx.fillStyle = `rgba(${col},0.15)`; ctx.strokeStyle = `rgb(${col})`; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.roundRect(x-w/2,y-h/2,w,h,4); ctx.fill(); ctx.stroke();
    ctx.fillStyle = `rgb(${col})`; ctx.font = '9px Space Mono, monospace';
    ctx.textAlign = 'center'; ctx.fillText(label, x, y+4); ctx.textAlign = 'left';
  }

  // Laser
  box(lx+25, ly, 50, 22, '94,240,200', 'LASER');
  // Beam splitter
  ctx.save(); ctx.translate(bsx,bsy); ctx.rotate(Math.PI/4);
  ctx.fillStyle='rgba(123,111,255,0.3)'; ctx.strokeStyle='rgb(123,111,255)'; ctx.lineWidth=1.5;
  ctx.fillRect(-4,-20,8,40); ctx.strokeRect(-4,-20,8,40);
  ctx.restore();
  ctx.fillStyle='rgb(123,111,255)'; ctx.font='9px Space Mono, monospace';
  ctx.fillText('BS',bsx+6,bsy-18);

  // Mirror
  ctx.fillStyle='rgba(94,240,200,0.3)'; ctx.strokeStyle='rgb(94,240,200)'; ctx.lineWidth=1.5;
  ctx.fillRect(mx-20,my-4,40,8); ctx.strokeRect(mx-20,my-4,40,8);
  ctx.fillStyle='rgb(94,240,200)'; ctx.font='9px Space Mono, monospace';
  ctx.fillText('M',mx+16,my-6);

  // Object
  ctx.strokeStyle='rgb(255,107,157)'; ctx.lineWidth=2;
  ctx.beginPath(); ctx.moveTo(ox,oy-22); ctx.lineTo(ox+16,oy+14); ctx.lineTo(ox-16,oy+14); ctx.closePath(); ctx.stroke();

  // Plate
  ctx.fillStyle='rgba(123,111,255,0.4)'; ctx.strokeStyle='rgb(123,111,255)'; ctx.lineWidth=2;
  ctx.fillRect(px-4, py-55, 8, 110); ctx.strokeRect(px-4, py-55, 8, 110);
  ctx.fillStyle='rgb(123,111,255)'; ctx.font='9px Space Mono, monospace';
  ctx.fillText('PLATE',px+4,py+62);

  // Beams
  arrow(lx+50,ly,bsx-12,bsy,'rgb(94,240,200)','');
  arrow(bsx,bsy,mx,my+4,'rgb(94,240,200)','Ref',bsx+4,(bsy+my)/2-8);
  arrow(mx,my+4,px-4,py-20,'rgb(94,240,200)','');
  arrow(bsx+12,bsy,ox-16,oy,'rgb(255,107,157)','Obj',bsx+18,bsy+12);
  // Scatter
  ctx.save(); ctx.globalAlpha=0.4;
  for (let i=-2;i<=2;i++) {
    arrow(ox+4,oy,px-4,py+i*20,'rgb(255,107,157)','');
  }
  ctx.restore();

  // Legend
  ctx.font='9px Space Mono, monospace';
  ctx.fillStyle='rgb(94,240,200)'; ctx.fillRect(W-110,8,10,3); ctx.fillText('Reference',W-96,13);
  ctx.fillStyle='rgb(255,107,157)'; ctx.fillRect(W-110,20,10,3); ctx.fillText('Object',W-96,25);
})();

(function reconstructDiagram() {
  const canvas = $('reconstructDiagram');
  const ctx = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;

  ctx.fillStyle = '#040509'; ctx.fillRect(0, 0, W, H);

  const px = 200, py = H/2;
  const srcX = 50, srcY = py - 60;
  const imgX = 100, imgY = py;
  const eyeX = W - 50, eyeY = py;

  function arrow(x1,y1,x2,y2,col) {
    ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = 1.8;
    ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(x2,y2); ctx.stroke();
    const ang = Math.atan2(y2-y1,x2-x1);
    ctx.beginPath();
    ctx.moveTo(x2,y2);
    ctx.lineTo(x2-10*Math.cos(ang-0.4), y2-10*Math.sin(ang-0.4));
    ctx.lineTo(x2-10*Math.cos(ang+0.4), y2-10*Math.sin(ang+0.4));
    ctx.closePath(); ctx.fill();
  }

  // Laser source
  ctx.fillStyle='rgba(94,240,200,0.15)'; ctx.strokeStyle='rgb(94,240,200)'; ctx.lineWidth=1.5;
  ctx.beginPath(); ctx.roundRect(srcX-25, srcY-10, 50, 20, 4); ctx.fill(); ctx.stroke();
  ctx.fillStyle='rgb(94,240,200)'; ctx.font='9px Space Mono, monospace';
  ctx.textAlign='center'; ctx.fillText('LASER',srcX,srcY+4); ctx.textAlign='left';

  // Plate
  ctx.fillStyle='rgba(123,111,255,0.4)'; ctx.strokeStyle='rgb(123,111,255)'; ctx.lineWidth=2;
  ctx.fillRect(px-4, py-55, 8, 110); ctx.strokeRect(px-4, py-55, 8, 110);
  ctx.fillStyle='rgb(123,111,255)'; ctx.font='9px Space Mono, monospace';
  ctx.fillText('HOLOGRAM',px-30,py+65);
  // Fringes on plate
  for (let y = py-50; y < py+50; y += 8) {
    ctx.fillStyle = 'rgba(255,255,200,0.35)';
    ctx.fillRect(px-3, y, 6, 4);
  }

  // Reference beam to plate
  arrow(srcX+25, srcY, px-4, py-25,'rgb(94,240,200)');
  ctx.fillStyle='rgb(94,240,200)'; ctx.font='9px Space Mono, monospace';
  ctx.fillText('ref beam', srcX+4, srcY-8);

  // Virtual image (ghost)
  ctx.save(); ctx.globalAlpha=0.45;
  ctx.strokeStyle='rgb(255,107,157)'; ctx.lineWidth=1.5;
  ctx.setLineDash([4,3]);
  ctx.beginPath(); ctx.moveTo(imgX,imgY-22); ctx.lineTo(imgX+16,imgY+14); ctx.lineTo(imgX-16,imgY+14); ctx.closePath(); ctx.stroke();
  ctx.setLineDash([]);
  ctx.restore();
  ctx.fillStyle='rgba(255,107,157,0.7)'; ctx.font='9px Space Mono, monospace';
  ctx.fillText('VIRTUAL\nIMAGE',imgX-30,imgY-32);

  // Diffracted beams: plate → eye
  ctx.save(); ctx.globalAlpha=0.5;
  for (let i=-3;i<=3;i++) {
    arrow(px+4, py+i*14, eyeX-18, eyeY+i*6,'rgb(94,240,200)');
  }
  ctx.restore();

  // Eye
  ctx.strokeStyle='rgb(255,215,0)'; ctx.fillStyle='rgba(255,215,0,0.15)'; ctx.lineWidth=2;
  ctx.beginPath(); ctx.ellipse(eyeX,eyeY,16,10,0,0,Math.PI*2); ctx.fill(); ctx.stroke();
  ctx.fillStyle='rgb(255,215,0)';
  ctx.beginPath(); ctx.arc(eyeX,eyeY,5,0,Math.PI*2); ctx.fill();
  ctx.fillStyle='rgb(255,215,0)'; ctx.font='9px Space Mono, monospace';
  ctx.fillText('EYE',eyeX+18,eyeY+4);

  // Dotted lines: eye → virtual image
  ctx.save(); ctx.globalAlpha=0.25;
  ctx.setLineDash([4,6]); ctx.strokeStyle='rgb(255,215,0)'; ctx.lineWidth=1;
  ctx.beginPath(); ctx.moveTo(eyeX-16,eyeY-5); ctx.lineTo(imgX+10,imgY-10); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(eyeX-16,eyeY+5); ctx.lineTo(imgX+10,imgY+10); ctx.stroke();
  ctx.setLineDash([]);
  ctx.restore();
})();

// ─── 3D VIEWER — Three.js ──────────────────
(function init3DViewer() {
  const canvas = $('viewerCanvas');

  // Size canvas
  function getSize() {
    return { w: canvas.parentElement.clientWidth - 220, h: 440 };
  }
  const { w, h } = getSize();
  canvas.width = w; canvas.height = h;

  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
  renderer.setSize(w, h);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setClearColor(0x04060f, 1);

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(55, w / h, 0.1, 200);
  camera.position.set(0, 3, 12);
  camera.lookAt(0, 0, 0);

  // Ambient + directional light
  scene.add(new THREE.AmbientLight(0x223344, 1.2));
  const dir = new THREE.DirectionalLight(0x5ef0c8, 2);
  dir.position.set(5, 8, 5);
  scene.add(dir);

  // ── Hologram plate ──
  const plateGeo = new THREE.BoxGeometry(4, 5, 0.06);
  const plateMat = new THREE.MeshPhysicalMaterial({
    color: 0x7b6fff, transparent: true, opacity: 0.35,
    roughness: 0.1, metalness: 0.2,
    transmission: 0.6
  });
  const plate = new THREE.Mesh(plateGeo, plateMat);
  scene.add(plate);

  // Fringe lines on plate (decorative)
  for (let i = -12; i <= 12; i++) {
    const lineGeo = new THREE.BoxGeometry(4, 0.03, 0.07);
    const lineMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.15 });
    const line = new THREE.Mesh(lineGeo, lineMat);
    line.position.set(0, i * 0.2, 0);
    plate.add(line);
  }

  // ── Virtual image (ghost tetrahedron) ──
  const imgGeo = new THREE.TetrahedronGeometry(1.1);
  const imgMat = new THREE.MeshPhysicalMaterial({
    color: 0xff6b9d, transparent: true, opacity: 0.55,
    emissive: 0xff6b9d, emissiveIntensity: 0.3,
    roughness: 0.2, wireframe: false
  });
  const imgObj = new THREE.Mesh(imgGeo, imgMat);
  imgObj.position.set(-3.5, 0, 1.5);
  scene.add(imgObj);
  // Wireframe overlay
  const wfMat = new THREE.MeshBasicMaterial({ color: 0xff6b9d, wireframe: true, transparent: true, opacity: 0.3 });
  const wfObj = new THREE.Mesh(imgGeo.clone(), wfMat);
  wfObj.position.copy(imgObj.position);
  scene.add(wfObj);

  // ── Reference beam (cone of light) ──
  const beamGeo = new THREE.CylinderGeometry(0.04, 0.04, 7, 8);
  const beamMat = new THREE.MeshBasicMaterial({ color: 0x5ef0c8, transparent: true, opacity: 0.6 });
  const beam = new THREE.Mesh(beamGeo, beamMat);
  beam.rotation.z = Math.PI / 2;
  beam.position.set(-3.2, 1.5, 3.5);
  beam.rotation.set(0.3, 0.1, Math.PI / 2);
  scene.add(beam);

  // ── Observer eye ──
  const eyeGeo = new THREE.SphereGeometry(0.3, 16, 16);
  const eyeMat = new THREE.MeshPhysicalMaterial({ color: 0xffd700, emissive: 0xffd700, emissiveIntensity: 0.5 });
  const eyeObj = new THREE.Mesh(eyeGeo, eyeMat);
  eyeObj.position.set(4.5, 0, 3);
  scene.add(eyeObj);

  // ── Diffracted rays (lines from plate to eye) ──
  const rayGroup = new THREE.Group();
  scene.add(rayGroup);
  const rayMat = new THREE.LineBasicMaterial({ color: 0x5ef0c8, transparent: true, opacity: 0.4 });
  for (let i = -3; i <= 3; i++) {
    const pts = [
      new THREE.Vector3(0.1, i * 0.6, 0),
      new THREE.Vector3(4.5, 0, 3)
    ];
    const rayGeo = new THREE.BufferGeometry().setFromPoints(pts);
    rayGroup.add(new THREE.Line(rayGeo, rayMat));
  }

  // ── Axes helper (subtle) ──
  // scene.add(new THREE.AxesHelper(3));

  // ── Grid ──
  const grid = new THREE.GridHelper(20, 20, 0x1a1f35, 0x0f1220);
  grid.position.y = -3;
  scene.add(grid);

  // ── Labels as sprites (simple) ──
  function makeLabel(text, color) {
    const cv = document.createElement('canvas');
    cv.width = 180; cv.height = 40;
    const c = cv.getContext('2d');
    c.fillStyle = color;
    c.font = 'bold 14px Space Mono, monospace';
    c.fillText(text, 4, 26);
    const tex = new THREE.CanvasTexture(cv);
    const mat = new THREE.SpriteMaterial({ map: tex, transparent: true });
    const sprite = new THREE.Sprite(mat);
    sprite.scale.set(2.5, 0.6, 1);
    return sprite;
  }
  const lblPlate = makeLabel('HOLOGRAM PLATE', '#7b6fff');
  lblPlate.position.set(0, 3.2, 0);
  scene.add(lblPlate);
  const lblImg = makeLabel('VIRTUAL IMAGE', '#ff6b9d');
  lblImg.position.set(-3.5, 2, 1.5);
  scene.add(lblImg);
  const lblEye = makeLabel('OBSERVER', '#ffd700');
  lblEye.position.set(5.2, 1, 3);
  scene.add(lblEye);

  // ── Orbit controls (manual) ──
  let isDragging = false, lastX = 0, lastY = 0;
  let theta = 0.3, phi = 0.3, radius = 13;
  let autoRotate = true;

  canvas.addEventListener('mousedown', e => { isDragging = true; lastX = e.clientX; lastY = e.clientY; });
  canvas.addEventListener('touchstart', e => { isDragging = true; lastX = e.touches[0].clientX; lastY = e.touches[0].clientY; });
  window.addEventListener('mouseup', () => isDragging = false);
  window.addEventListener('touchend', () => isDragging = false);
  window.addEventListener('mousemove', e => {
    if (!isDragging) return;
    theta -= (e.clientX - lastX) * 0.005;
    phi = clamp(phi - (e.clientY - lastY) * 0.005, -1.2, 1.2);
    lastX = e.clientX; lastY = e.clientY;
    autoRotate = false;
  });
  window.addEventListener('touchmove', e => {
    if (!isDragging) return;
    theta -= (e.touches[0].clientX - lastX) * 0.007;
    phi = clamp(phi - (e.touches[0].clientY - lastY) * 0.007, -1.2, 1.2);
    lastX = e.touches[0].clientX; lastY = e.touches[0].clientY;
    autoRotate = false;
  });
  canvas.addEventListener('wheel', e => {
    radius = clamp(radius + e.deltaY * 0.02, 5, 30);
  });

  // Play/pause button
  $('viewerPlay').addEventListener('click', () => {
    autoRotate = !autoRotate;
    $('viewerPlay').textContent = autoRotate ? '⏸ Pause Auto-Rotate' : '▶ Resume Auto-Rotate';
  });

  // ── Animate ──
  let viewT = 0;
  function animate() {
    requestAnimationFrame(animate);
    viewT += 0.01;
    if (autoRotate) theta += 0.006;

    camera.position.x = radius * Math.sin(theta) * Math.cos(phi);
    camera.position.y = radius * Math.sin(phi);
    camera.position.z = radius * Math.cos(theta) * Math.cos(phi);
    camera.lookAt(0, 0, 0);

    // Animate virtual image
    imgObj.rotation.y = viewT * 0.5;
    wfObj.rotation.y = imgObj.rotation.y;
    imgMat.opacity = 0.4 + 0.2 * Math.sin(viewT * 0.7);

    // Pulse beam
    beamMat.opacity = 0.4 + 0.25 * Math.sin(viewT * 2);

    renderer.render(scene, camera);
  }
  animate();

  // Resize
  window.addEventListener('resize', () => {
    const { w, h } = getSize();
    if (w < 50) return;
    renderer.setSize(w, h);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  });
})();

// ─── INTERSECTION OBSERVER — fade-in ───────
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
    }
  });
}, { threshold: 0.1 });

document.querySelectorAll('.card, .physics-block, .stage-card, .fringe-panel, .fringe-explain').forEach(el => {
  el.style.opacity = '0';
  el.style.transform = 'translateY(24px)';
  el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
  observer.observe(el);
});
